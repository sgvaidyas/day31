﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace day31_1
{
    public partial class Insert : Form
    {
        SqlConnection conn;

        public Insert()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ConnectionString);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 ob = new Form1();
            ob.Show();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            PlayerClass ob = new PlayerClass();
            ob.Pid =int.Parse(txtpid.Text.ToString());
            ob.Pname = txtname.Text.ToString();
            ob.Cat = txtcat.Text.ToString();
            ob.Score = int.Parse(txtscore.Text.ToString());

            string query = "insert into Player values("+ob.Pid + ",'" + ob.Pname + "',' " + ob.Cat + "', " + ob.Score +")";
            MessageBox.Show(query);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("RECORD INSERTED SUCCESSFULLY");
                clear();
            }
            catch(Exception)
            {
                MessageBox.Show("couldnt connect to db ");
            }
            finally
            {
                conn.Close();
            }
        }
        void clear()
        {
            txtpid.Text = "";
            txtname.Text = "";
            txtcat.Text = "";
            txtscore.Text = "";
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void Insert_Load(object sender, EventArgs e)
        {
            try
            {
                string query = "Select max(Pid)+1 from Player";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                string id = cmd.ExecuteScalar().ToString();
                txtpid.Text = id;
                
            }
            catch(Exception)
            {
                MessageBox.Show("Not able to connect");
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
