﻿namespace day31_1
{
    partial class Insert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btnbacktomain = new System.Windows.Forms.Button();
            this.txtpid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtcat = new System.Windows.Forms.TextBox();
            this.txtscore = new System.Windows.Forms.TextBox();
            this.btnclear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "PID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(45, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "CATEGORY";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "SCORE";
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(48, 250);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 31);
            this.btnsubmit.TabIndex = 4;
            this.btnsubmit.Text = "SUBMIT";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // btnbacktomain
            // 
            this.btnbacktomain.Location = new System.Drawing.Point(173, 250);
            this.btnbacktomain.Name = "btnbacktomain";
            this.btnbacktomain.Size = new System.Drawing.Size(154, 31);
            this.btnbacktomain.TabIndex = 5;
            this.btnbacktomain.Text = "BACK TO MAIN";
            this.btnbacktomain.UseVisualStyleBackColor = true;
            this.btnbacktomain.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtpid
            // 
            this.txtpid.Location = new System.Drawing.Point(202, 44);
            this.txtpid.Name = "txtpid";
            this.txtpid.Size = new System.Drawing.Size(153, 20);
            this.txtpid.TabIndex = 6;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(202, 91);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(153, 20);
            this.txtname.TabIndex = 7;
            // 
            // txtcat
            // 
            this.txtcat.Location = new System.Drawing.Point(202, 142);
            this.txtcat.Name = "txtcat";
            this.txtcat.Size = new System.Drawing.Size(153, 20);
            this.txtcat.TabIndex = 8;
            // 
            // txtscore
            // 
            this.txtscore.Location = new System.Drawing.Point(202, 189);
            this.txtscore.Name = "txtscore";
            this.txtscore.Size = new System.Drawing.Size(153, 20);
            this.txtscore.TabIndex = 9;
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(370, 250);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(75, 31);
            this.btnclear.TabIndex = 10;
            this.btnclear.Text = "CLEAR";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // Insert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.txtscore);
            this.Controls.Add(this.txtcat);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtpid);
            this.Controls.Add(this.btnbacktomain);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Insert";
            this.Text = "Insert";
            this.Load += new System.EventHandler(this.Insert_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnbacktomain;
        private System.Windows.Forms.TextBox txtpid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtcat;
        private System.Windows.Forms.TextBox txtscore;
        private System.Windows.Forms.Button btnclear;
    }
}