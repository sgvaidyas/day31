﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day31_1
{
    class PlayerClass
    {
        public int Pid { get; set; }
        public string Pname { get; set; }
        public string Cat { get; set; }
        public int Score { get; set; }
    }
}
