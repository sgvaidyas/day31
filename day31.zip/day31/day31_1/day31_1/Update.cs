﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace day31_1
{
    public partial class Update : Form
    {
        SqlConnection conn;
        public Update()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ConnectionString);

        }

        private void Update_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }
        void clear()
        {
            txtpid.Text = "";
            panel1.Visible = false;
        }


     

        private void btnsearch_Click_1(object sender, EventArgs e)
        {
            string id = txtpid.Text;
            string query = "select * from Player where Pid=" + id;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    rd.Read();
                    txtpname.Text = rd[1].ToString();
                    txtcat.Text = rd[2].ToString();
                    txtscore.Text = rd[3].ToString();
                    panel1.Visible = true;
                }
                else
                {
                    MessageBox.Show("Record Not found with the id = " + id);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Problem with connection");
            }
            finally
            {
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string id = txtpid.Text;
                string pname = txtpname.Text;
                string pcat = txtcat.Text;
                string score = txtscore.Text;

                string query = "update Player set Pname = ' " + pname + "', Category = ' " + pcat + "', Score = " + score + " where Pid =  " + id;
                MessageBox.Show(query);

                SqlCommand cm = new SqlCommand(query, conn);
                conn.Open();
                cm.ExecuteNonQuery();
                MessageBox.Show("Updated the  record with pid =  " + id);
                clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Couldnt connect to db ");
            }
            finally
            {
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 ob = new Form1();
            ob.Show();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
