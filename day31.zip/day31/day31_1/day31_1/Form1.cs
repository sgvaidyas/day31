﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day31_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Insert ob = new Insert();
            ob.Show();
            this.Hide();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            btnbacktomain ob = new btnbacktomain();
            ob.Show();
            this.Hide();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Update ob = new Update();
            ob.Show();
            this.Hide();
        }

        private void btnlist_Click(object sender, EventArgs e)
        {
            List ob = new List();
            ob.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            Delete ob = new Delete();
            ob.Show();
            this.Hide();
        }

        private void btnproc_Click(object sender, EventArgs e)
        {
            Procedure ob = new Procedure();
            ob.Show();
            this.Hide();
        }

        private void btnprocparam_Click(object sender, EventArgs e)
        {
            Procedurewithparam ob = new Procedurewithparam();
            ob.Show();
            this.Hide();
        }
    }
}
