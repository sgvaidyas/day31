﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace day31_1
{
    public partial class Delete : Form
    {
        SqlConnection conn;
        public Delete()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ConnectionString);

        }
        void clear()
        {
            txtpid.Text = "";
            panel1.Visible = false;
        }


        private void btnsearch_Click(object sender, EventArgs e)
        {
            string id = txtpid.Text;
            string query = "select * from Player where Pid=" + id;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    rd.Read();
                    lblpid.Text = id;
                    lblpname.Text = rd[1].ToString();
                    lblcat.Text = rd[2].ToString();
                    lblscore.Text = rd[3].ToString();
                    panel1.Visible = true;
                }
                else
                {
                    MessageBox.Show("Record Not found with the id = " + id);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Problem with connection");
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 ob = new Form1();
            ob.Show();
        }

        private void Delete_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string id = txtpid.Text;

                string query = "delete from Player where Pid=" + id;
                SqlCommand cm = new SqlCommand(query, conn);
                conn.Open();
                cm.ExecuteNonQuery();
                MessageBox.Show("Deleted record ");
                clear();
            }
            catch(Exception)
            {
                MessageBox.Show("Couldnt connect to db ");
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
