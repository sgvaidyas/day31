﻿namespace day31_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btninsert = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnlist = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnproc = new System.Windows.Forms.Button();
            this.btnprocparam = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(38, 41);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(102, 91);
            this.btninsert.TabIndex = 0;
            this.btninsert.Text = "INSERT";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(180, 41);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(102, 91);
            this.btnsearch.TabIndex = 1;
            this.btnsearch.Text = "SEARCH";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(327, 41);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(102, 91);
            this.btnupdate.TabIndex = 2;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnlist
            // 
            this.btnlist.Location = new System.Drawing.Point(468, 41);
            this.btnlist.Name = "btnlist";
            this.btnlist.Size = new System.Drawing.Size(102, 91);
            this.btnlist.TabIndex = 3;
            this.btnlist.Text = "LIST";
            this.btnlist.UseVisualStyleBackColor = true;
            this.btnlist.Click += new System.EventHandler(this.btnlist_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(603, 41);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(102, 91);
            this.btndelete.TabIndex = 4;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnproc
            // 
            this.btnproc.Location = new System.Drawing.Point(38, 186);
            this.btnproc.Name = "btnproc";
            this.btnproc.Size = new System.Drawing.Size(102, 91);
            this.btnproc.TabIndex = 5;
            this.btnproc.Text = "PROCEDURE";
            this.btnproc.UseVisualStyleBackColor = true;
            this.btnproc.Click += new System.EventHandler(this.btnproc_Click);
            // 
            // btnprocparam
            // 
            this.btnprocparam.Location = new System.Drawing.Point(183, 186);
            this.btnprocparam.Name = "btnprocparam";
            this.btnprocparam.Size = new System.Drawing.Size(102, 91);
            this.btnprocparam.TabIndex = 6;
            this.btnprocparam.Text = "PROCEDUREWITH PARAM";
            this.btnprocparam.UseVisualStyleBackColor = true;
            this.btnprocparam.Click += new System.EventHandler(this.btnprocparam_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnprocparam);
            this.Controls.Add(this.btnproc);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnlist);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.btninsert);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnlist;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnproc;
        private System.Windows.Forms.Button btnprocparam;
    }
}

